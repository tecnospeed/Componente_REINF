﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REINF_CSharp
{
    public partial class Form1 : Form
    {
        ReinfClientX.spdReinfClientX reinf = new ReinfClientX.spdReinfClientX();

        public Form1()
        {
            InitializeComponent();            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            reinf.CpfCnpjEmpregador = "08187168000160";
            reinf.DiretorioTemplates = @"C:\Program Files\TecnoSpeed\Reinf\Arquivos\Templates\";
            reinf.DiretorioEsquemas = @"C:\Program Files\TecnoSpeed\Reinf\Arquivos\Esquemas\";
            reinf.Ambiente = ReinfClientX.AmbienteKind.akPreProducaoReais;
            reinf.VersaoManual = ReinfClientX.VersaoManualKind.vm11;

            string[] vetor;
            vetor = reinf.ListarCertificados("|").Split('|');

            cbbCertificado.Items.Clear();
            for (int i = 0; i < vetor.Length; i++)
            {
                cbbCertificado.Items.Add(vetor[i]);
            }
        }

        private void btnConfigurarSH_Click(object sender, EventArgs e)
        {
            reinf.ConfigurarSoftwareHouse(tbCNPJSH.Text, tbTokenSH.Text);
        }

        private void btnCarregaTx2_Click(object sender, EventArgs e)
        {
            tbRetorno.Text += "INCLUIRR1000 \r\n";
            tbRetorno.Text += "tpAmb_4=2 \r\n";
            tbRetorno.Text += "procEmi_5=1 \r\n";
            tbRetorno.Text += "verProc_6=1.0 \r\n";
            tbRetorno.Text += "tpInsc_8=1 \r\n";
            tbRetorno.Text += "nrInsc_9=08187168000160 \r\n";
            tbRetorno.Text += "iniValid_13=2017-01 \r\n";
            tbRetorno.Text += "classTrib_16=01 \r\n";
            tbRetorno.Text += "indEscrituracao_17=0 \r\n";
            tbRetorno.Text += "indDesoneracao_18=1 \r\n";
            tbRetorno.Text += "indAcordoIsenMulta_19=0 \r\n";
            tbRetorno.Text += "indSitPJ_20=0 \r\n";
            tbRetorno.Text += "nmCtt_22=Nome do Contato \r\n";
            tbRetorno.Text += "cpfCtt_23=12345678909 \r\n";
            tbRetorno.Text += "foneFixo_24=1123452345 \r\n";
            tbRetorno.Text += "SALVARR1000 \r\n";
        }

        private void btnAssinar_Click(object sender, EventArgs e)
        {
            tbRetorno.Text = reinf.AssinarEvento(tbRetorno.Text);
        }

        private void btnGerarXML_Click(object sender, EventArgs e)
        {
            tbRetorno.Text = reinf.GerarXMLporTx2(tbRetorno.Text);
        }

        private void cbbCertificado_SelectedIndexChanged(object sender, EventArgs e)
        {
            reinf.NomeCertificado = cbbCertificado.Text;
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            ReinfClientX.IspdRetEnviarLoteEventos retEnvio;
            retEnvio = reinf.EnviarLoteEventos(tbRetorno.Text);
            tbRetorno.Clear();
            tbRetorno.Text += "Identificador do Lote: " + retEnvio.IdLote + "\r\n";
            tbRetorno.Text += "Mensagem de Retorno: " + retEnvio.Mensagem + "\r\n";

            tbIDLote.Text = retEnvio.IdLote;
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            ReinfClientX.IspdRetConsultarLote retConsulta;
            ReinfClientX.IspdRetConsultarLoteItem retConsultaItem;
            ReinfClientX.IspdRetConsultarLoteOcorrencia retConsultaOcorrencia;

            retConsulta = reinf.ConsultarLoteEventos(tbIDLote.Text);

            tbRetorno.Clear();
            tbRetorno.Text += "Número do Protocolo: " + retConsulta.NumeroProtocolo + "\r\n";
            tbRetorno.Text += "Mensagem do Retorno: " + retConsulta.Mensagem + "\r\n";
            tbRetorno.Text += "Status do Lote: " + retConsulta.Status + "\r\n";

            for (int i = 0; i < retConsulta.Count() ; i++)
            {
                retConsultaItem = retConsulta.Eventos[i];
                tbRetorno.Text += "     Evento: " + i + 1 + "\r\n";
                tbRetorno.Text += "     Id Evento: " + retConsultaItem.IdEvento + "\r\n";
                tbRetorno.Text += "     Número Recibo: " + retConsultaItem.NumeroRecibo + "\r\n";
                tbRetorno.Text += "     Código Status: " + retConsultaItem.Status + "\r\n";
                tbRetorno.Text += "     Mensagem: " + retConsultaItem.Mensagem + "\r\n";
                tbRetorno.Text += "     Status do Evento: " + retConsultaItem.Status + "\r\n";

                for (int j = 0; j < retConsultaItem.Count(); j++)
                {
                    retConsultaOcorrencia = retConsultaItem.Ocorrencias[j];
                    tbRetorno.Text += "          Ocorrencia: " + j+1 + "\r\n";
                    tbRetorno.Text += "          Código: " + retConsultaOcorrencia.Codigo + "\r\n";
                    tbRetorno.Text += "          Descrição: " + retConsultaOcorrencia.Descricao + "\r\n";
                }
            }

        }
    }
}
