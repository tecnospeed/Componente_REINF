﻿namespace REINF_CSharp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbCNPJSH = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbTokenSH = new System.Windows.Forms.TextBox();
            this.btnConfigurarSH = new System.Windows.Forms.Button();
            this.cbbCertificado = new System.Windows.Forms.ComboBox();
            this.btnCarregaTx2 = new System.Windows.Forms.Button();
            this.tbRetorno = new System.Windows.Forms.TextBox();
            this.btnGerarXML = new System.Windows.Forms.Button();
            this.btnAssinar = new System.Windows.Forms.Button();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tbIDLote = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CPF / CNPJ Software House";
            // 
            // tbCNPJSH
            // 
            this.tbCNPJSH.Location = new System.Drawing.Point(12, 25);
            this.tbCNPJSH.Name = "tbCNPJSH";
            this.tbCNPJSH.Size = new System.Drawing.Size(144, 20);
            this.tbCNPJSH.TabIndex = 1;
            this.tbCNPJSH.Text = "05316687973";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(159, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Token Software House";
            // 
            // tbTokenSH
            // 
            this.tbTokenSH.Location = new System.Drawing.Point(162, 25);
            this.tbTokenSH.Name = "tbTokenSH";
            this.tbTokenSH.Size = new System.Drawing.Size(168, 20);
            this.tbTokenSH.TabIndex = 3;
            this.tbTokenSH.Text = "N1Z6Iz5SxY6P9xqFojlI4gKzcKzUD144EAUGJkH8";
            // 
            // btnConfigurarSH
            // 
            this.btnConfigurarSH.Location = new System.Drawing.Point(336, 25);
            this.btnConfigurarSH.Name = "btnConfigurarSH";
            this.btnConfigurarSH.Size = new System.Drawing.Size(75, 20);
            this.btnConfigurarSH.TabIndex = 4;
            this.btnConfigurarSH.Text = "Configurar";
            this.btnConfigurarSH.UseVisualStyleBackColor = true;
            this.btnConfigurarSH.Click += new System.EventHandler(this.btnConfigurarSH_Click);
            // 
            // cbbCertificado
            // 
            this.cbbCertificado.FormattingEnabled = true;
            this.cbbCertificado.Location = new System.Drawing.Point(12, 51);
            this.cbbCertificado.Name = "cbbCertificado";
            this.cbbCertificado.Size = new System.Drawing.Size(399, 21);
            this.cbbCertificado.TabIndex = 5;
            this.cbbCertificado.SelectedIndexChanged += new System.EventHandler(this.cbbCertificado_SelectedIndexChanged);
            // 
            // btnCarregaTx2
            // 
            this.btnCarregaTx2.Location = new System.Drawing.Point(12, 78);
            this.btnCarregaTx2.Name = "btnCarregaTx2";
            this.btnCarregaTx2.Size = new System.Drawing.Size(75, 23);
            this.btnCarregaTx2.TabIndex = 6;
            this.btnCarregaTx2.Text = "Carrega Tx2";
            this.btnCarregaTx2.UseVisualStyleBackColor = true;
            this.btnCarregaTx2.Click += new System.EventHandler(this.btnCarregaTx2_Click);
            // 
            // tbRetorno
            // 
            this.tbRetorno.Location = new System.Drawing.Point(11, 145);
            this.tbRetorno.Multiline = true;
            this.tbRetorno.Name = "tbRetorno";
            this.tbRetorno.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbRetorno.Size = new System.Drawing.Size(399, 282);
            this.tbRetorno.TabIndex = 7;
            // 
            // btnGerarXML
            // 
            this.btnGerarXML.Location = new System.Drawing.Point(93, 78);
            this.btnGerarXML.Name = "btnGerarXML";
            this.btnGerarXML.Size = new System.Drawing.Size(75, 23);
            this.btnGerarXML.TabIndex = 8;
            this.btnGerarXML.Text = "Gerar XML";
            this.btnGerarXML.UseVisualStyleBackColor = true;
            this.btnGerarXML.Click += new System.EventHandler(this.btnGerarXML_Click);
            // 
            // btnAssinar
            // 
            this.btnAssinar.Location = new System.Drawing.Point(174, 78);
            this.btnAssinar.Name = "btnAssinar";
            this.btnAssinar.Size = new System.Drawing.Size(75, 23);
            this.btnAssinar.TabIndex = 9;
            this.btnAssinar.Text = "Assinar";
            this.btnAssinar.UseVisualStyleBackColor = true;
            this.btnAssinar.Click += new System.EventHandler(this.btnAssinar_Click);
            // 
            // btnEnviar
            // 
            this.btnEnviar.Location = new System.Drawing.Point(255, 78);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(75, 23);
            this.btnEnviar.TabIndex = 10;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // btnConsultar
            // 
            this.btnConsultar.Location = new System.Drawing.Point(336, 78);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(75, 23);
            this.btnConsultar.TabIndex = 11;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = true;
            this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Identificador do Lote";
            // 
            // tbIDLote
            // 
            this.tbIDLote.Location = new System.Drawing.Point(12, 120);
            this.tbIDLote.Name = "tbIDLote";
            this.tbIDLote.Size = new System.Drawing.Size(398, 20);
            this.tbIDLote.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 439);
            this.Controls.Add(this.tbIDLote);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnConsultar);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.btnAssinar);
            this.Controls.Add(this.btnGerarXML);
            this.Controls.Add(this.tbRetorno);
            this.Controls.Add(this.btnCarregaTx2);
            this.Controls.Add(this.cbbCertificado);
            this.Controls.Add(this.btnConfigurarSH);
            this.Controls.Add(this.tbTokenSH);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbCNPJSH);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Demo REINF";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbCNPJSH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbTokenSH;
        private System.Windows.Forms.Button btnConfigurarSH;
        private System.Windows.Forms.ComboBox cbbCertificado;
        private System.Windows.Forms.Button btnCarregaTx2;
        private System.Windows.Forms.TextBox tbRetorno;
        private System.Windows.Forms.Button btnGerarXML;
        private System.Windows.Forms.Button btnAssinar;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbIDLote;
    }
}

